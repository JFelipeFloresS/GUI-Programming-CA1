package barberapp.main;

/**
 *
 * @author José Felipe Flores da Silva
 * 2019405
 * GUI Programming
 * CA1
 * 
 */

public class BarberApp{
    
    public static void main(String[] args) {
        new Controller();
    }
}